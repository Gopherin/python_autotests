import requests
import pytest

URL = 'https://api.pokemonbattle.ru/v2/'
TOKEN = 'c215b408ea160775b2152c8c55731080'
HEADER = {'Content-Type': 'application/json', 'trainer_token': TOKEN}
TRAINER_ID = '11572'


def test_status_code():
    try:
        response = requests.get(f'{URL}trainers', headers = HEADER)
        assert response.status_code == 200
    except Exception as e:
        print(f"Произошла ошибка: {e}")
        raise e


def test_trainer_id():
    try:
        response_id = requests.get(f'{URL}trainers', params={'trainer_id' : TRAINER_ID})
        assert response_id.json()["data"][0]["id"] == TRAINER_ID
    except Exception as e:
        print(f"Произошла ошибка: {e}")
        raise e
