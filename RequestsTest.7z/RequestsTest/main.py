import requests

# URL API
URL = 'https://api.pokemonbattle.ru/v2/'

# Ваш токен
TOKEN = 'c215b408ea160775b2152c8c55731080'

# Заголовки для запросов
HEADER = {'Content-Type': 'application/json', 'trainer_token':TOKEN}

# Данные для создания покемона
BODY_POKEMON = {
    "name": "Бульбазавр",
    "photo_id": 1
}

# Данные для обновления покемона
BODY_PUT_POKEMON = {
    "pokemon_id": "164499",  # Здесь нужно указать реальный ID покемона
    "name": "Username",
    "photo_id": 2
}

# Данные для ловли покемона
BODY_CATCH_POKEMON = {
    "pokemon_id": "127183"  # Здесь также нужно указать реальный ID покемона
}

# Создание нового покемона
RESPONSE_POKEMON = requests.post(url = f'{URL}pokemons', headers = HEADER, json = BODY_POKEMON)
print(RESPONSE_POKEMON.text)

# Обновление существующего покемона
RESPONSE_PUT_POKEMON = requests.put(url = f'{URL}pokemons', headers = HEADER, json = BODY_PUT_POKEMON)
print(RESPONSE_PUT_POKEMON.text)

# Ловля покемона
RESPONSE_CATCH_POKEMON = requests.post(url = f'{URL}trainers/add_pokeball', headers = HEADER, json = BODY_CATCH_POKEMON)
print(RESPONSE_CATCH_POKEMON.text)